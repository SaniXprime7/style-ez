STYLEMATCH MEN'S — ANDROID APK BUILD GUIDE
==========================================

This folder contains the StyleMatch web app packaged as a Capacitor Android project starter.
The included HTML app is in www/index.html.

LOW-COST ROUTE
--------------
Building an APK is free with Android Studio + the Android SDK, but the standard native build
requires a computer (Windows, macOS, or Linux). This ZIP is source code, not a compiled APK.
It does not contain Android Studio, the Android SDK, or a signing key.

REQUIREMENTS ON A COMPUTER
--------------------------
1. Install Node.js LTS from https://nodejs.org/
2. Install Android Studio from https://developer.android.com/studio
3. In Android Studio, open SDK Manager and install a current Android SDK Platform and
   Android SDK Build-Tools. Accept the licenses.
4. Extract this ZIP to a normal folder.

BUILD STEPS
-----------
Open a terminal/Command Prompt in the extracted stylematch_android_project folder and run:

   npm install
   npx cap add android
   npx cap sync android
   npx cap open android

If `npx cap add android` says the Android platform already exists, skip that command and run
`npx cap sync android`.

Android Studio will open the generated `android` folder:
5. Wait for Gradle sync to finish.
6. Connect your Android phone by USB and enable Developer options > USB debugging, OR use
   an Android emulator.
7. Select the phone/emulator in the top toolbar.
8. Press Run (green triangle) to install a test build.

TO CREATE AN APK FILE
---------------------
In Android Studio:
Build > Build Bundle(s) / APK(s) > Build APK(s)

When the build completes, click "locate" in the notification. The debug APK is usually at:
android/app/build/outputs/apk/debug/app-debug.apk

Transfer that APK to your Android phone, tap it in Files, and allow "Install unknown apps"
for the app you used to open it if Android asks. Only install APKs you built yourself or
trust; turn the permission back off afterward if you enabled it just for this install.

FOR A RELEASE APK
-----------------
Use Build > Generate Signed Bundle / APK > APK. Create and safely back up your own keystore.
Never share the keystore or its password. A release APK must be signed; losing the keystore
can prevent you from updating the same app later.

IMPORTANT NOTES
---------------
- Outfit photos use remote image URLs and need internet access.
- Favorites and wardrobe items use browser localStorage. WebView storage normally persists
  for the app, but uninstalling/clearing app data can erase it.
- This is a prototype. The outfit suggestions use local rules, not a live AI model.
- This starter uses Capacitor 7. For current compatibility details and install requirements,
  consult https://capacitorjs.com/docs and https://developer.android.com/studio.
- If you only have your Android phone and no computer, the easiest free no-code-like option
  is to install the existing HTML prototype in Chrome as a home-screen shortcut/PWA-style
  experience. A standalone APK build entirely on Android is more complicated and is not
  guaranteed by this source package.
